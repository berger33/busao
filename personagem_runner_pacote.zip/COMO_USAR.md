# Personagem runner para Blender e Godot

Este pacote contém um gerador Python e uma personagem original criada por modelagem procedural, inspirada na roupa, cores e cabelo da referência. O acabamento é simplificado e estilizado: não equivale a uma personagem esculpida e texturizada manualmente no nível de GTA IV. O rosto foi inventado porque a imagem mostra as costas.

## Executar o código no Blender

1. Abra o Blender e entre na área **Scripting**.
2. No **Text Editor**, use **Open** para abrir `criar_personagem_runner.py`. Não use o menu de abrir projetos `.blend` para esse passo.
3. Clique em **Run Script** (triângulo de reprodução) ou pressione **Alt+P** com o cursor no editor de texto.
4. Aguarde a criação dos arquivos e as duas prévias. Os renders podem levar alguns minutos, dependendo da máquina.

Não precisa instalar bibliotecas Python ou add-ons: execute o código no Python do Blender. Foi testado no Blender **5.2.2 LTS** instalado nesta máquina. Compatibilidade com outras versões não foi verificada.

O script cria uma cena chamada `Personagem_Runner`. Ele preserva os objetos da cena anterior e salva um novo `.blend`, que passa a ser o projeto aberto na sessão. A saída fica em uma pasta `personagem_runner` ao lado do script. Quando essa pasta já contém arquivos, o script cria outra com data e hora, sem substituir a anterior.

O modelo e o GLB são salvos antes das prévias, para sobreviver a uma eventual interrupção do render.

## Arquivos já gerados

- `personagem_runner/personagem_runner.blend`: personagem editável, esqueleto, animações e estúdio de apresentação.
- `personagem_runner/personagem_runner.glb`: personagem exportada, com materiais, imagens, pesos e animações embutidos; sem o estúdio.
- `personagem_runner/previa_frente.png`: aparência frontal.
- `personagem_runner/previa_corrida.png`: corrida vista por trás.
- `personagem_runner/informacoes_modelo.json`: contagens e configurações da geração.
- `personagem_runner/validacao_glb.json`: resultados da reimportação do GLB no Blender.

Para ver a corrida, abra o `.blend` e pressione Espaço sobre a Timeline ou a viewport. A cena fica preparada nos frames 1–24 a 30 fps. A chave no frame 25 fecha o ciclo de 0,8 segundo. O clipe `idle` tem 2 segundos.

## Levar para o Godot 4

1. Copie apenas `personagem_runner.glb` para uma pasta dentro do seu projeto Godot.
2. Aguarde a importação. Instancie o GLB como o visual do seu personagem.
3. Reproduza `run_loop` usando o AnimationPlayer importado ou seu AnimationTree. Ative a repetição da animação nas configurações de importação; o formato glTF não define automaticamente a reprodução contínua no jogo.
4. Use um `CharacterBody3D` com colisão configurada no Godot para movimentar o personagem. O arquivo traz o visual e o esqueleto; não traz um controlador de jogo nem colisões.
5. A frente local do asset no Godot é **+Z**. Se o seu controlador avança em **-Z**, gire apenas o nó visual em 180° no eixo Y.
6. Posicione a câmera atrás e um pouco acima da personagem, olhando na direção da corrida.

A corrida é **in-place**: o root fica fixo. O avanço em direção ao horizonte é responsabilidade do controlador do jogo. A velocidade de referência da passada é aproximadamente **2,06 m/s**; ao alterar muito a velocidade de deslocamento, ajuste também a velocidade de reprodução para reduzir o deslizamento dos pés.

As cores usam o atributo de vértice `COLOR_0`, além das texturas de detalhe. Se substituir os materiais no Godot, preserve o uso da cor dos vértices como albedo.

## Ajustes no Python

Procure estas opções no script:

- `OUTPUT_DIR`: pasta de saída; deixe vazio para usar a localização do script.
- `RENDER_PREVIEWS`: use `False` para gerar o modelo sem renderizar PNGs.
- `TEXTURE_SIZE`: resolução das imagens de detalhe; padrão 512.
- `skin_color`, `shirt_color`, `shorts_color`, `hair_color`: cores principais em hexadecimal.

O rig contém 25 ossos, incluindo três para o cabelo. Os dedos têm geometria, mas não possuem controle individual; acompanham o osso da mão. A malha foi construída para esta corrida e idle; poses extremas e animações adicionais podem exigir ajuste de pesos.

## Limites da validação

Foram verificadas geração, exportação e reimportação no Blender. O relatório acompanha o arquivo e distingue as verificações aprovadas. Ainda não houve teste dentro do Godot nem em um aparelho Android. O orçamento de geometria é uma meta inicial, não uma garantia de FPS: iluminação, cenário, sombras e outros personagens também influenciam o desempenho.
